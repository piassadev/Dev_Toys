﻿using iTextSharp.text.pdf.codec.wmf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DevToys
{
    public class TaxReceipt
    {
        public string TaxReceiptValue { get; set; }

        public void CreateReceipt(
        string login,
        string cupom,
        string street,
        string formPayment,
        string city,
        string state,
        string cep,
        int number,
        decimal valueToys,
        decimal tax,
        decimal valueTotal,
        Guid id)
        {
            if (cupom == "DESCONTO10")
            {
                Console.Clear();


               this.TaxReceiptValue = $"===================================================\n" +
                                      $"|             Destinatário: {login}                \n" +
                                      $"===================================================\n" +
                                      $"|Rua de Entrega: {street}, N: {number}             \n" +
                                      $"|Cidade de Entrega: {city}, {state} {cep}          \n" +
                                      $"===================================================\n" +
                                      $"|Valor sem Entrega: R${valueToys:F2}               \n" +
                                      $"|Taxa de Entrega: R${tax:F2}                       \n" +
                                      $"|CUPOM: DESCONTO10                                 \n" +
                                      $"|Valor Total: R${valueTotal:F2}                    \n" +
                                      $"|FORMA DE PAGAMENTO: R${formPayment:F2}            \n" +
                                      $"===================================================\n" +
                                      $"|ID DE VENDA: {id}                                 \n" +
                                      $"===================================================\n" +
                                      $"|(C) 2023 DevToys-Todos os direitos reservados.    \n" +
                                      $"===================================================\n";
            }
            else
            {

                this.TaxReceiptValue = $"===================================================\n" +
                                       $"|             Destinatário: {login}                \n" +
                                       $"===================================================\n" +
                                       $"|Rua de Entrega: {street}, N: {number}             \n" +
                                       $"|Cidade de Entrega: {city}, {state} {cep}          \n" +
                                       $"===================================================\n" +
                                       $"|Valor sem Entrega: R${valueToys:F2}               \n" +
                                       $"|Taxa de Entrega: R${tax:F2}                       \n" +
                                       $"|Valor Total: R${valueTotal:F2}                    \n" +
                                       $"|FORMA DE PAGAMENTO: R${valueTotal:F2}             \n" +
                                       $"|FORMA DE PAGAMENTO: R${formPayment:F2}            \n" +
                                       $"===================================================\n" +
                                       $"|ID DE VENDA: {id}                                 \n" +
                                       $"===================================================\n" +
                                       $"|(C) 2023 DevToys-Todos os direitos reservados.    \n" +
                                       $"===================================================\n";
            }
        }
    }
}
