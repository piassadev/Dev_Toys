﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys
{
    public class RequestsUsers
    {
        public string OptionLogin => "Escolha uma opção:" +
            "\n1. Logar" +
            "\n2. Cadastrar";

        public string OptionActionSite => "Deseja Realizar Qual ação em nosso Site?" +
            "\n1 - Gerar Carrinho de Produtos" +
            "\n2 - Verificar status de compra" +
            "\n3 - sair do Site";

        public string OptionToys => "Qual tipo de brinquedo você quer deseja?\n" +
            "\n1 - carros" +
            "\n2 - bolas";

        public string OptionAction => "\nDESEJA:\n" +
            "\n3 - EFETIVAR COMPRA" +
            "\n4 - LIMPAR CARRINHO";
    }
}
