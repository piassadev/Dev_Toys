﻿namespace DevToys.Models.Validates
{
    public class Validate
    {
        public OutputValidateLogin ValidateLogin(string login, string password, DataBase data)
        {
            var output = new OutputValidateLogin();
            output.ReturnCode = ReturnCode.Success;
            var listError = new List<string>();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                listError.Add("Campo Login ou Senha não pode ser nulo ou vazio");
                output.AddError(listError.ToArray());
            }

            if (password.Length < 8 || password.Length > 20)
            {
                listError.Add("Senha não se encaixa no padrão  (Min: 8 Max: 20)");
                output.AddError(listError.ToArray());
            }

            if (output.ReturnCode != ReturnCode.Failed)
            {
                var user = login + password;

                if (data.Login != null)
                {
                    foreach (string userLogin in data.Login)
                    {
                        if (user == userLogin)
                        {
                            return output;
                        }

                        listError.Add("Usuario nao tem cadastro");
                        output.AddError(listError.ToArray());

                    }
                }

                listError.Add("Usuario nao tem cadastro");
                output.AddError(listError.ToArray());
            }

            return output;
        }

        public OutputValidateLogin ValidateRegister(string login, string password, DataBase data)
        {
            var output = new OutputValidateLogin();
            output.ReturnCode = ReturnCode.Success;
            var listError = new List<string>();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                listError.Add("Campo Login ou Senha não pode ser nulo ou vazio");
                output.AddError(listError.ToArray());
            }

            if (password.Length < 8 || password.Length > 20)
            {
                listError.Add("Senha não se encaixa no padrão  (Min: 8 Max: 20)");
                output.AddError(listError.ToArray());
            }

            if (output.ReturnCode == ReturnCode.Success)
            {
                var user = login + password;

                if (data.Login != null)
                {
                    foreach (string userLogin in data.Login)
                    {
                        if (user == userLogin)
                        {
                            listError.Add("Usuario ja cadastrado");
                            output.AddError(listError.ToArray());
                        }

                    }
                }
                data.AddUser(login, password);
            }

            return output;
        }

        public OutputValidateLogin ValidateCard(string nome, string number, string date, string cod)
        {
            var output = new OutputValidateLogin();
            output.ReturnCode = ReturnCode.Success;
            var listError = new List<string>();

            if (string.IsNullOrEmpty(nome))
            {
                listError.Add("Campo NOME DO TITULAR não pode ser nulo ou vazio");
                output.AddError(listError.ToArray());
            }
            if (string.IsNullOrEmpty(number))
            {
                listError.Add("Campo NUMERO DO CARTAO não pode ser nulo ou vazio");
                output.AddError(listError.ToArray());
            }

            if (string.IsNullOrEmpty(date))
            {
                listError.Add("Campo DATA DE VENCIMENTO não pode ser nulo ou vazio");
                output.AddError(listError.ToArray());
            }

            if (string.IsNullOrEmpty(cod))
            {
                listError.Add("Campo COD não pode ser nulo ou vazio");
                output.AddError(listError.ToArray());
            }

            return output;
        }

        public OutputValidateLogin ValidateCupom(string cupom, DataBase data)
        {
            var output = new OutputValidateLogin();
            output.ReturnCode = ReturnCode.Success;
            var listError = new List<string>();

            if (string.IsNullOrEmpty(cupom))
            {
                listError.Add("Campo CUPOM não pode ser vazio");
                output.AddError(listError.ToArray());
            }

            if (output.ReturnCode == ReturnCode.Success)
            {
                if (data.Login != null)
                {
                    foreach (string cupomData in data.Cupons)
                    {
                        if (cupom != cupomData)
                        {
                            listError.Add("Cupom não existe");
                            output.AddError(listError.ToArray());
                        }
                    }
                }
            }

            return output;
        }
    }
}
