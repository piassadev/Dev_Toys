﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.Models
{
    public class OutputOptionSales
    {
        public OutputOptionSales(decimal valueToys, bool loppingReturnAdress)
        {
            this.ValueToys = valueToys;
            this.LoppingReturnAdress = loppingReturnAdress;
        }
        public decimal ValueToys { get; set; }
        public bool LoppingReturnAdress { get; set; }
    }
}
