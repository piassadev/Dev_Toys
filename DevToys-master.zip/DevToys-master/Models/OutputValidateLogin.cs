﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.Models
{
    public class OutputValidateLogin
    {
        public OutputValidateLogin() { }

        public ReturnCode ReturnCode { get; set; }
        public Error Error { get; set; }

        public void AddError(string[] message)
        {
            Error = new Error(message);
            ReturnCode = ReturnCode.Failed;
        }
    }
}
