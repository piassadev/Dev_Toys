﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.Models
{
    public class OutputOptionPreSales
    {
        public OutputOptionPreSales(bool menuToys, decimal valueToys ) 
        { 
            this.MenuToys = menuToys;
            this.ValueToys = valueToys;
        }

        public OutputOptionPreSales(bool menuToys, decimal valueToys, bool brinqLopping) 
        {
            this.MenuToys = menuToys;
            this.ValueToys = valueToys;
            this.BrinqLopping = brinqLopping;
        }

        public bool MenuToys { get; set; } 
        public decimal ValueToys { get; set; }
        public bool BrinqLopping { get; set; }
    }
}
