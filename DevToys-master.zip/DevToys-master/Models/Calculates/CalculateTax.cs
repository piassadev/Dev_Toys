﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys
{
    public class CalculateTax
    {
        public decimal TaxValue { get; set; }
        public void Calculate(decimal numberHouse)
        {
            if(numberHouse <= 10) 
            {
                this.TaxValue = 10m;            
            }
            else if (numberHouse <= 20)
            {
                this.TaxValue = 20m;
            }
            else if (numberHouse <= 30)
            {
                this.TaxValue = 30m;
            }
            else
            {
                this.TaxValue = 40m;
            }
        }
    }
}
