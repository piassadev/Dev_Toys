﻿using System;
using System.Collections.Generic;

public class CalculateInstallment
{
    public List<decimal> ValueInstallment { get; private set; }

    public CalculateInstallment()
    {
        ValueInstallment = new List<decimal>();
    }

    public void Calculate(decimal valueTotal)
    {
        int maxParcel = 5;

        for(int i = 1; i <= maxParcel; i++)
        {
            var calculate = valueTotal / i;

            decimal valor = Math.Round(calculate, 2);

            ValueInstallment.Add(valor);
        }
    }
}
