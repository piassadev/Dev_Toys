﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys
{
    public class ReturnLopping
    {
        public ReturnLopping(bool cicloTwo, bool shouldRetry) 
        { 
            this.CicloTwo = cicloTwo;
            this.ShouldRetry = shouldRetry;
        }

        public ReturnLopping(bool brinqLopping)
        {
            this.BrinqLopping = brinqLopping;
        }
        public bool CicloTwo { get; set; }
        public bool ShouldRetry { get; set; }
        public bool BrinqLopping { get; set; }
    }
}
