﻿using DevToys.Models.Validates;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.classes
{
    public class PreSalesService
    {
        public ReturnLopping CreatePreSales(bool brinqLopping, Titles title, RequestsUsers request, decimal valueToys, DataBase dataBase, string login)
        {
            #region CRIACAO_LOPPING

            Console.Clear();
            var menuToys = true;
            brinqLopping = false;

            var tax = new CalculateTax();

            #endregion CRIACAO_LOPPING

            while (menuToys)
            {
                Console.Clear();

                #region ACAO_CARRINHO/TIPO_BRINQUEDOS

                Console.WriteLine($"{title.PreSales}\n");
                Console.WriteLine($"VALOR TOTAL: R${valueToys}");

                Console.WriteLine($"{request.OptionToys}");

                //Se ja existir brinquedo no carrinho, dar opção de progredir ou resetar
                if (valueToys > 0)
                {
                    Console.WriteLine($"{request.OptionAction}");
                }

                var optionToys = int.Parse(Console.ReadLine());

                #endregion CARRINHO/TIPO BRINQUEDOS

                //Se opção no carrinho for diferente de 4 = resetar
                if (optionToys != 4)
                {
                    var optionSales = new OptionPreSalesService();
                    var sales = optionSales.CreateOptionSales(optionToys, dataBase, valueToys, title, brinqLopping, menuToys, login);

                    menuToys = sales.MenuToys;
                    valueToys = sales.ValueToys;
                    brinqLopping = sales.BrinqLopping;
                }

                else
                {
                    valueToys = 0;

                    menuToys = true;

                    Console.WriteLine("Reiniciando Carrinho em 2 segundos...");
                    Thread.Sleep(2000);
                    Console.Clear();
                }
            }
            return new ReturnLopping(brinqLopping);
        }
    }
}
