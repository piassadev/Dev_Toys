﻿namespace DevToys.classes
{
    public class OutputOptionPaymentService
    {
        public bool MenuToys { get; set; }
        public decimal ValueToys { get; set; }
        public bool BrinqLopping { get; set; }
        public bool LoppingReturnAdress { get; set; }

        public OutputOptionPaymentService(bool menuToys, bool loppingReturnAdress, bool brinqLopping, decimal valueToys)
        {
            this.MenuToys = menuToys;
            this.ValueToys = valueToys;
            this.BrinqLopping = brinqLopping;
            this.LoppingReturnAdress = loppingReturnAdress;
        }
    }
}