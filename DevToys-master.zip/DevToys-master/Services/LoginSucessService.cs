﻿using DevToys.Models.Validates;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.classes
{
    public class LoginSucessService
    {
       public ReturnLopping LoginProgress(bool cicloTwo, bool shouldRetry, Titles title, RequestsUsers request, DataBase dataBase, string login)
        {
            Console.Clear();

            cicloTwo = false;
            var brinqLopping = true;

            decimal valueToys = 0;
            var tax = new CalculateTax();

            while (brinqLopping)
            {
                Console.Clear();

                //Mensagem de bem vindo
                Console.WriteLine($"{title.Welcome}\n");

                //Opções de ação do site no menu
                Console.WriteLine(request.OptionActionSite);
                var actionOption = int.Parse(Console.ReadLine());

                if (actionOption == 1)
                {
                    var pre = new PreSalesService();
                    var preLopping = pre.CreatePreSales(brinqLopping, title, request, valueToys, dataBase, login);

                    shouldRetry = preLopping.ShouldRetry;
                    brinqLopping = preLopping.BrinqLopping;

                }

                #region VERIFICAR_STATUS_COMPRAR

                if (actionOption == 2)
                {
                    List<string> sales = new List<string>();

                    string[] arraySales = new string[10];

                    var salesLopping = true;

                    while (salesLopping)
                    {
                        if (dataBase.Sales != null)
                        {
                            Console.Clear();
                            Console.WriteLine($"{title.Status}\n\n");
                            foreach (var data in dataBase.Sales)
                            {
                                int i = 1;
                                Console.WriteLine($"COMPRA - {i++}  " +
                                    $"\nID: {data.Id.ToString()}" +
                                    $"\nVALOR: {data.Value}" +
                                    $"\nSTATUS: {data.Status}");

                            }

                            Console.WriteLine("\n\nDESEJA:" +
                                "\n1 - Voltar ao MENU" +
                                "\n2 - Sair do SITE");

                            var saleOption = int.Parse(Console.ReadLine());

                            if (saleOption == 1)
                            {
                                Console.WriteLine("Reiniciando Login em 3 segundos...");
                                Thread.Sleep(3000);
                                Console.Clear();
                                break;
                            }
                            if (saleOption == 2)
                            {
                                shouldRetry = true;
                                cicloTwo = false;
                                brinqLopping = false;

                                Console.WriteLine($"{title.Mario}");
                                Thread.Sleep(1000);
                                Console.Clear();
                                break;
                            }

                        }
                        else
                        {
                            brinqLopping = true;
                            Console.WriteLine("NÃO TEM COMPRAS EFETUADAS EM NOSSO SITE");
                            Console.WriteLine("Reiniciando Menu em 3 segundos...");
                            Thread.Sleep(3000);
                            Console.Clear();
                            break;
                        }
                    }
                }

                #endregion VERIFICAR_STATUS_COMPRAR

                #region SAIR_SITE

                if (actionOption == 3)
                {
                    shouldRetry = true;
                    cicloTwo = false;
                    brinqLopping = false;

                    Console.WriteLine($"{title.Mario}");
                    Thread.Sleep(1000);
                    Console.Clear();


                    return new ReturnLopping(cicloTwo, shouldRetry);
                }

                #endregion SAIR_SITE
            }

            return new ReturnLopping(cicloTwo, shouldRetry);
        }
    }
}
