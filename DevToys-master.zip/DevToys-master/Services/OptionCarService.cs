﻿using DevToys.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.classes
{
    public class OptionCarService
    {
        public OutputOptionSales Car(DataBase dataBase, decimal valueToys, bool loppingReturnAdress)
        {
            Console.Clear();
            var carLopping = true;
            while (carLopping)
            {
                string cars = string.Join("", dataBase.Cars);
                Console.WriteLine($"{cars}");
                Console.WriteLine("\n6 - VOLTAR AS OPÇÕES DE BRINQUEDO");

                Console.WriteLine("\n Qual Opção Deseja?");
                var optionCar = int.Parse(Console.ReadLine());

                #region CALCULOS_CARROS

                switch (optionCar)
                {
                    case 1:
                        valueToys = valueToys + 10m;
                        Console.WriteLine("Brinquedo Adicionado ao carrinho" +
                             $"\n VALOR ATUAL DO CARRINHO: R${valueToys} ");
                        carLopping = false;
                        loppingReturnAdress = false;
                        break;
                    case 2:
                        valueToys = valueToys + 15m;
                        Console.WriteLine("Brinquedo Adicionado ao carrinho" +
                             $"\n VALOR ATUAL DO CARRINHO: R${valueToys} ");
                        carLopping = false;
                        loppingReturnAdress = false;
                        break;
                    case 3:
                        valueToys = valueToys + 12m;
                        Console.WriteLine("Brinquedo Adicionado ao carrinho" +
                             $"\n VALOR ATUAL DO CARRINHO: R${valueToys} ");
                        carLopping = false;
                        loppingReturnAdress = false;
                        break;
                    case 4:
                        valueToys = valueToys + 13m;
                        Console.WriteLine("Brinquedo Adicionado ao carrinho" +
                             $"\n VALOR ATUAL DO CARRINHO: R${valueToys} ");
                        carLopping = false;
                        loppingReturnAdress = false; break;
                    case 5:
                        valueToys = valueToys + 16m;
                        Console.WriteLine("Brinquedo Adicionado ao carrinho" +
                             $"\n VALOR ATUAL DO CARRINHO: R${valueToys} ");
                        carLopping = false;
                        loppingReturnAdress = false; break;
                    case 6:
                        Console.WriteLine($"\n VALOR ATUAL DO CARRINHO: R${valueToys} ");
                        carLopping = false;
                        loppingReturnAdress = false; break;
                }

                #endregion CALCULOS_CARROS

                Console.Clear();

            }
            return new OutputOptionSales(valueToys, loppingReturnAdress);
        }
    }
}
