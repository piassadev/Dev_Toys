﻿using DevToys.Models.Validates;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.classes
{
    public class LoginService
    {
        public ReturnLopping Metod(DataBase dataBase, RequestsUsers request, Titles title, bool shouldRetry)
        {
            Console.Clear();

            shouldRetry = false;
            bool cicloTwo = true;

            while (cicloTwo)
            {
                #region INSERIR_LOGIN

                Console.WriteLine(title.Login);
                string login = Console.ReadLine();

                Console.WriteLine(title.Password);
                string password = Console.ReadLine();

                #endregion INSERIR_LOGIN

                #region VALIDAR_LOGIN

                var validate = new Validate();
                var valid = validate.ValidateLogin(login, password, dataBase);

                #endregion VALIDAR_LOGIN

                #region LOGIN_SUCESSO

                if (valid.ReturnCode == ReturnCode.Success)
                {
                    var logSucess = new LoginSucessService();
                    var loginLopping = logSucess.LoginProgress(cicloTwo, shouldRetry, title, request, dataBase, login);

                    shouldRetry = loginLopping.ShouldRetry;

                    cicloTwo = loginLopping.CicloTwo;
                }

                #endregion LOGIN_SUCESSO

                else
                {
                    string arrayAsString = string.Join(",\n ", valid.Error.Message);
                    Console.WriteLine($"ERROR: {arrayAsString}\n");

                    Console.WriteLine("Deseja Retornar para efetuar o cadastro?\n\n" +
                        "1 - SIM \n" +
                        "2 - NÃO");

                    var optionReturn = int.Parse(Console.ReadLine());

                    if (optionReturn == 1)
                    {
                        shouldRetry = true;

                        Console.WriteLine("Reiniciando Menu em 3 segundos...");
                        Thread.Sleep(3000);
                        Console.Clear();
                        break;
                    }

                    Console.WriteLine("Reiniciando Login em 3 segundos...");
                    Thread.Sleep(3000);
                    Console.Clear();
                }
            }
            return new ReturnLopping(cicloTwo, shouldRetry);
        }
    }
}
