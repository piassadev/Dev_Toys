﻿using DevToys.Models.Validates;
using DevToys.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.classes
{
    public class OptionPaymentService
    {
        public OutputOptionPaymentService Payment(decimal valueToys, decimal valueTotal, DataBase dataBase, Titles title, int number, string cep, string state, string city, string street, string login, bool menuToys, bool loppingReturnAdress, bool brinqLopping)
        {
            Console.Clear();

            var tax = new CalculateTax();
            #region CRIACAO_LOPPING

            var paymentLopping = true;

            #endregion CRIACAO_LOPPING
            while (paymentLopping)
            {
                Console.WriteLine($"Valor: {valueToys}" +
                $"\nTaxa: {tax.TaxValue}" +
                $"\nValor Total: {valueTotal}\n\n");

                string cupom = "";

                var cupomLopping = true;
                while (cupomLopping)
                {
                    Console.Clear();

                    Console.WriteLine("TEM CUPOM DE DESCONTO?" +
                 "\n1 - Sim" +
                 "\n2 - Não");

                    var optionCupom = int.Parse(Console.ReadLine());

                    if (optionCupom == 1)
                    {
                        Console.Write("DIGITE O CUPOM:");
                        cupom = Console.ReadLine();

                        var validate = new Validate();
                        var validCupom = validate.ValidateCupom(cupom, dataBase);

                        if (validCupom.ReturnCode == ReturnCode.Success)
                        {
                            cupomLopping = false;
                            valueTotal = valueTotal - 10;

                            Console.WriteLine($"\nValor com Desconto: {valueTotal}\n\n");

                            break;
                        }

                        string erroCupom = string.Join(",\n ", validCupom.Error.Message);
                        Console.WriteLine($"\nERROR: {erroCupom}\n");

                        Console.WriteLine("\nDeseja digitar novamente o cupom?" +
                            "\n1 - Sim" +
                            "\n2 - Não");
                        var remainigCupom = int.Parse(Console.ReadLine());

                        if (remainigCupom == 1)
                        {
                            cupom = "";
                            Console.WriteLine("Reiniciando Cupom em 3 segundos...");

                            Thread.Sleep(3000);
                        }
                        else
                        {
                            cupomLopping = false;
                        }
                    }
                    else
                    {
                        cupomLopping = false;
                    }
                }


                Console.WriteLine($"{title.Payment}" +
                    "\n\n1 - Credito" +
                    "\n2 - Debito" +
                    "\n3 - Pix");

                var paymentMetod = int.Parse(Console.ReadLine());

                string formPayment = "";

                switch (paymentMetod)
                {
                    case 1:
                        formPayment = "Credito";
                        break;
                    case 2:
                        formPayment = "Debito";
                        break;
                    case 3:
                        formPayment = "Pix";
                        break;
                }

                int perc;

                #region PAGAMENTO_CREDITO

                if (paymentMetod == 1)
                {

                    Console.Write($"{title.CardData}" +
                        "\n\nNOME DO TITULAR:");
                    var nome = Console.ReadLine();

                    Console.Write("\nNUMERO DO CARTAO:");
                    var numberCard = Console.ReadLine();

                    Console.Write("\nDATA DE VENCIMENTO:");
                    var dateVenc = Console.ReadLine();

                    Console.Write("\nCOD: ");
                    var codigo = Console.ReadLine();

                    var validate = new Validate();
                    var cardValid = validate.ValidateCard(nome,
                        numberCard,
                        dateVenc,
                        codigo);

                    if (cardValid.ReturnCode != ReturnCode.Success)
                    {
                        string cardError = string.Join(",\n ", cardValid.Error.Message);

                        Console.WriteLine($"ERROR: {cardError}\n");
                        Console.WriteLine("Reiniciando Pagamento em 3 segundos...");

                        Thread.Sleep(3000);

                        break;
                    }

                    var calculate = new CalculateInstallment();
                    calculate.Calculate(valueTotal);

                    var loppingParcel = true;

                    while (loppingParcel)
                    {

                        Console.WriteLine($"\n{title.Parcel}\n\n");

                        for (int i = 0; i < calculate.ValueInstallment.Count; i++)
                        {
                            Console.WriteLine($"{i + 1}X: R${calculate.ValueInstallment[i]}\n");
                        }

                        perc = int.Parse(Console.ReadLine());

                        if (perc > 5 || perc < 1)
                        {
                            Console.WriteLine("Não temos essa opção de parcela");
                            Console.WriteLine("Reiniciando Pagamento em 3 segundos...");

                            Thread.Sleep(3000);

                            break;
                        }

                        else
                        {
                            Console.WriteLine("========== PAGAMENTO APROVADO ==========");
                            Thread.Sleep(1000);
                            break;
                        }
                    }

                }

                #endregion PAYMENT_CREDITO

                #region PAGAMENTO_DEBITO
                if (paymentMetod == 2)
                {
                    Console.Write($"{title.CardData}" +
                        "\n\nNOME DO TITULAR:");
                    var nome = Console.ReadLine();

                    Console.Write("\nNUMERO DO CARTAO:");
                    var numberCard = Console.ReadLine();

                    Console.Write("\nDATA DE VENCIMENTO:");
                    var dateVenc = Console.ReadLine();

                    Console.Write("\nCOD: ");
                    var codigo = Console.ReadLine();

                    var validate = new Validate();
                    var cardValid = validate.ValidateCard(nome,
                        numberCard,
                        dateVenc,
                        codigo);

                    if (cardValid.ReturnCode != ReturnCode.Success)
                    {
                        string cardError = string.Join(",\n ", cardValid.Error.Message);

                        Console.WriteLine($"ERROR: {cardError}\n");
                        Console.WriteLine("Reiniciando Pagamento em 3 segundos...");

                        Thread.Sleep(3000);

                        break;
                    }

                }

                #endregion PAGAMENTO_DEBITO

                #region PAGAMENTO_PIX

                if (paymentMetod == 3)
                {

                    var qr = new QrCode();
                    Console.WriteLine(qr.code);
                    Thread.Sleep(13000);

                }

                #endregion PAGAMENTO_PIX

                var id = Guid.NewGuid();

                var taxReceipt = new TaxReceipt();

                taxReceipt.CreateReceipt(
                  login,
                  cupom,
                  street,
                  formPayment,
                  city,
                  state,
                  cep,
                  number,
                  valueToys,
                  tax.TaxValue,
                  valueTotal,
                  id);

                paymentLopping = false;

                Console.Clear();
                Console.Clear();

                Console.WriteLine($"{title.Congratulations}\n");
                Console.WriteLine($"{taxReceipt.TaxReceiptValue}");


                dataBase.AddSales(id, valueTotal);

                Console.WriteLine($"Retornando ao menu em 8 segundos");
                Thread.Sleep(8000);

                brinqLopping = true;
                loppingReturnAdress = false;
                menuToys = false;

                Console.Clear();

            }
            return new OutputOptionPaymentService(menuToys, loppingReturnAdress, brinqLopping, valueToys);
        }
    }
}
