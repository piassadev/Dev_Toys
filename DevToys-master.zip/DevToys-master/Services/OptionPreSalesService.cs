﻿using DevToys.Models;
using DevToys.Models.Validates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevToys.classes
{
    public class OptionPreSalesService
    {
        public OutputOptionPreSales CreateOptionSales(int optionToys, DataBase dataBase, decimal valueToys, Titles title, bool brinqLopping, bool menuToys, string login)
        {
            var tax = new CalculateTax();

            #region CRIACAO_LOPPING

            var loppingReturnAdress = true;

            #endregion CRIACAO_LOPPING

            while (loppingReturnAdress)
            {
                #region OPCAO_CARRINHOS

                if (optionToys == 1)
                {
                    var optionBall = new OptionCarService();
                    var outputBall = optionBall.Car(dataBase, valueToys, loppingReturnAdress);

                    valueToys = outputBall.ValueToys;
                    loppingReturnAdress = outputBall.LoppingReturnAdress;
                }

                #endregion OPCAO_CARRINHOS

                #region OPCAO_BOLAS

                if (optionToys == 2)
                {
                    var optionBall = new OptionBallService();
                    var outputBall = optionBall.Ball(dataBase, valueToys, loppingReturnAdress);

                    valueToys = outputBall.ValueToys;
                    loppingReturnAdress = outputBall.LoppingReturnAdress;
                }

                #endregion OPCAO_BOLAS

                //Efetivar Compra
                if (optionToys == 3)
                {

                    decimal valueTotal = 0;

                    Console.Clear();

                    #region PREENCHER_ENDERECO

                    Console.WriteLine($"\n VALOR ATUAL DO CARRINHO: R${valueToys} \n");

                    Console.WriteLine($"{title.Adress}\n");

                    Console.Write("Rua: ");
                    string street = Console.ReadLine();

                    Console.Write("Numero: ");
                    var number = int.Parse(Console.ReadLine());

                    Console.Write("Cidade: ");
                    string city = Console.ReadLine();

                    Console.Write("Estado: ");
                    string state = Console.ReadLine();

                    Console.Write("CEP: ");
                    string cep = Console.ReadLine();

                    #endregion PREENCHER_ENDERECO

                    #region CALCULAR_FRETE

                    tax.Calculate(number);
                    valueTotal = valueToys + tax.TaxValue;

                    #endregion CALCULAR_FRETE

                    Console.WriteLine($"\n\nTAXA: {tax.TaxValue}" +
                        $"\nVALOR TOTAL: {valueTotal}");

                    Console.WriteLine("\n\nDESEJA:" +
                        "\n1 - Prosseguir" +
                        "\n2 - Retornar");

                    var next = int.Parse(Console.ReadLine());

                    if (next == 1)
                    {
                        brinqLopping = false;
                    }
                    else
                    {
                        brinqLopping = false;
                        menuToys = true;

                        Console.WriteLine("Reiniciando Menu em 3 segundos...");
                        Thread.Sleep(3000);

                        break;
                    }

                    var payment = new OptionPaymentService();
                    var outputPayment = payment.Payment(
                        valueToys, 
                        valueTotal, 
                        dataBase, 
                        title, 
                        number,
                        cep,
                        state,
                        city,
                        street, 
                        login, 
                        menuToys, 
                        loppingReturnAdress, 
                        brinqLopping);

                    valueToys = outputPayment.ValueToys;
                    brinqLopping = outputPayment.BrinqLopping;
                    loppingReturnAdress = outputPayment.LoppingReturnAdress;
                    menuToys = outputPayment.MenuToys;
                   

                    return new OutputOptionPreSales(menuToys, valueToys, brinqLopping);
                }

            }
            return new OutputOptionPreSales(menuToys, valueToys, brinqLopping);
        }
    }
}
