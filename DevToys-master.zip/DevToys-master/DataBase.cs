﻿
namespace DevToys
{
    public class DataBase
    {
        public List<ProductSale?> Sales { get; set; }

        public string[] Cupons = new string[]
        {
            "DESCONTO10"
        };
        public string[] Login {get; set;}

        public string[] Cars = new string[6]
        {
            @"
───█▒▒███
───███████
───████████
─███████████
██───████████
█─▄█▄─████████
█─▀█▀─█████████
██───███████████
─█████████▓▓▓▓██
───███████▓▓▓▓██
───█▀▀▀▀▀███████
───███████▓▓▓▓██
───███████▓▓▓▓██
───███████▓▓▓▓██
───███████▓▓▓▓█
───███████▓▓▄▀
───███████▄▀
───███████
─█████████
██───█████
█─▄█▄─████
█─▀█▀─████
██───████▀
─███████▀
───█▒▒█▀",
            "\n\n1 - Carrinho de Construção R$10.00",
            "\n2 - Carrinho de Encaixe R$15.00",
            "\n3 - Carrinho com Controle Remoto 12.00",
            "\n4 - Carrinho de Aprendizado Eletrônicos 13.00",
            "\n5 - Carrinho de Ciência 16.00"
        };  
        
        public string[] Ball = new string[6]
        {
            @"
▓▓▓▓▓▓▓▓▓▓▓▓████████████
▓▓▓▓▓▓▓▓███████▒▒▒▒▒▒▒▒▒███
▓▓▓▓▓█████████▒▒▒▒▒▒▒▒▒▒▒▒████
▓▓▓▓██▒███▒▒▒▒██▒▒▒▒▒▒▒▒▒█▒▒▒██
▓▓▓█▒▒▒█▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒█▒▒▒▒▒▒██
▓▓█▒▒▒█▒▒▒▒▒▒▒▒▒▒████████▒▒▒▒▒▒▒██
▓█▒▒▒██▒▒▒▒▒▒▒▒▒█████████▒▒▒▒▒▒▒▒█
██▒▒▒█▒▒▒▒▒▒▒▒▒▒██████████▒▒▒▒▒▒▒▒█
█▒▒▒██▒▒▒▒▒▒▒▒████████████▒▒▒▒▒▒▒▒█
█▒▒█████▒▒▒███▒▒▒███████▒▒████▒▒▒██
███████████▒▒▒▒▒▒▒▒███▒▒▒▒▒▒▒▒█████
█▒███████▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒████
█▒███████▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒████
▓█▒██████▒▒▒▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒▒▒███
▓▓█▒██▒▒██▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒██▒██
▓▓▓██▒▒▒▒▒███▒▒▒▒█████▒▒▒▒███▒▒▒█
▓▓▓▓██▒▒▒▒▒▒███████████████▒▒▒██
▓▓▓▓▓███▒▒▒▒▒▒██████████▒▒▒▒██
▓▓▓▓▓▓▓████▒▒▒█████████▒▒███
▓▓▓▓▓▓▓▓▓▓█████▒▒▒▒▒▒████
",
            "\n1 - Bola de Textura Diferente R$10,00",
            "\n2 - Bola de Equilíbrio R$15,00",
            "\n3 - Bola de Letras e Números R$12,00",
            "\n4 - Bola de Quebra-Cabeça 13.00",
            "\n5 - Bola de Malabarismo 16.00"
        };

        public void AddUser(string login, string password)
        {
            var log = login + password;

            Login = new string[] { log };
        }

        public void AddSales(Guid id, decimal value)
        {
            var listSales = new List<ProductSale>();
            var product = new ProductSale(id, value);
            listSales.Add(product);

            Sales = listSales;
            
        }


    }
}
