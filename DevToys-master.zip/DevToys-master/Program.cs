﻿using DevToys;
using DevToys.classes;
using DevToys.Models.Validates;

class Program
{
    static void Main()
    {
        var dataBase = new DataBase();
        var request = new RequestsUsers();

        bool shouldRetry = true;
        while (shouldRetry)
        {
            Console.Clear();

            //Nome da Empresa
            var title = new Titles();
            Console.WriteLine(title.Logo);

            //Opções de Login
            Console.WriteLine($"{request.OptionLogin}");
            string escolha = Console.ReadLine();


            if (escolha == "1")
            {
                var log = new LoginService();
                 var loginLopping = log.Metod(dataBase, request, title, shouldRetry);

                shouldRetry = true;
                
            }

            #region CADASTRAR

            else if (escolha == "2")
            {
                var LoppingCad = true;
                while (LoppingCad)
                {
                    Console.Clear();
                    Console.Write(title.Register + "\n");

                    Console.WriteLine(title.Login);
                    string login = Console.ReadLine();

                    Console.WriteLine(title.Password);
                    string password = Console.ReadLine();

                    var validate = new Validate();
                    var valid = validate.ValidateRegister(login, password, dataBase);

                    if (valid.ReturnCode == ReturnCode.Success)
                    {
                        shouldRetry = true;
                        LoppingCad = false;
                        Console.WriteLine("Cadastro Efetuado com Sucesso");
                        Console.WriteLine("Retornando ao Menu Principal para Efetuar o Login em 3 segundos...");
                        Thread.Sleep(3000);
                    }
                    else
                    {
                        string arrayAsString = string.Join(",\n ", valid.Error.Message);
                        Console.WriteLine($"ERROR: {arrayAsString}\n");

                        Console.WriteLine("Deseja Retornar para efetuar o Login?\n\n" +
                            "1 - SIM \n" +
                            "2 - NÃO");

                        var optionReturn = int.Parse(Console.ReadLine());

                        if (optionReturn == 1)
                        {
                            shouldRetry = true;
                            Console.WriteLine("Reiniciando Menu em 3 segundos...");
                            Thread.Sleep(3000);
                            break;
                        }

                        shouldRetry = false;
                        LoppingCad = true;
                        Console.WriteLine("Reiniciando Cadastro em 3 segundos...");
                        Thread.Sleep(3000);
                    }
                }

            }

            #endregion CADASTRAR

            else
            {
                Console.WriteLine("Opção inválida. Por favor, escolha 1 para fazer login ou 2 para cadastrar.");
                Thread.Sleep(3000);
                Console.WriteLine("Reiniciando Menu em 3 segundos...");
            }
        }
    }
}

